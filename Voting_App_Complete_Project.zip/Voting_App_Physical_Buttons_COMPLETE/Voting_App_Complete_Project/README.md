# Voting App Physical Buttons — Complete Demo Package

## Architecture
ESP32 + Cat/Dog buttons → MQTT (`voting/vote`) → Mosquitto + Voting Service on Minikube → REST dashboard + MQTT tally → OLED.

## What is included
- `backend/`: live voting API + MQTT subscriber + dashboard
- `k8s/`: Mosquitto and voting-service Kubernetes manifests
- `esp32/`: firmware for 2 buttons + SSD1306 I2C OLED
- final presentation and demo checklist

## 1. Install on laptop
Install Docker Desktop, Minikube, kubectl, and Arduino IDE. In Arduino IDE install ESP32 board support plus libraries: **PubSubClient**, **Adafruit GFX**, **Adafruit SSD1306**.

## 2. Start Minikube and deploy
Open a terminal in this project folder:

### Windows PowerShell
```powershell
minikube start --driver=docker
minikube image build -t voting-app:1.0 ./backend
kubectl apply -f k8s/mosquitto-config.yaml
kubectl apply -f k8s/mosquitto.yaml
kubectl apply -f k8s/voting-app.yaml
kubectl rollout status deployment/mosquitto
kubectl rollout status deployment/voting-app
kubectl get pods,svc
minikube service voting-app --url
```
Open the URL printed by the last command. Keep that terminal open if Minikube says a tunnel is required.

## 3. Test software BEFORE hardware
On the dashboard press **Test Cat Vote** and **Test Dog Vote**. Counts must change. Then check:
```powershell
kubectl logs deployment/voting-app --tail=50
```
The dashboard should show API ready and MQTT connected.

## 4. Wire hardware
Using the firmware defaults:
- Cat button: GPIO 18 ↔ button ↔ GND
- Dog button: GPIO 19 ↔ button ↔ GND
- OLED VCC → 3.3V (or board/module-supported supply), GND → GND
- OLED SDA → ESP32 default SDA (commonly GPIO 21)
- OLED SCL → ESP32 default SCL (commonly GPIO 22)

**Confirm your exact ESP32/OLED pinout before powering it.** The sketch uses `INPUT_PULLUP`, so each button connects the GPIO to GND when pressed.

## 5. Configure ESP32
Run:
```powershell
minikube ip
```
Edit the top of `esp32/voting_buttons_esp32.ino`:
- `WIFI_SSID`
- `WIFI_PASSWORD`
- `MQTT_HOST` = output of `minikube ip`

Upload to ESP32. Open Serial Monitor at 115200. The ESP32 and laptop must be on a network setup where the ESP32 can reach the Minikube NodePort `31883`.

## 6. Live demo
1. Open dashboard and reset tally.
2. Show Cat=0, Dog=0.
3. Press physical Cat button once → Cat becomes 1 on dashboard and OLED.
4. Press physical Dog button once → Dog becomes 1.
5. Explain: button event → ESP32 publishes MQTT → broker → Minikube voting service counts → tally published/served → OLED + web update.

## Important fallback for tomorrow
If the ESP32 cannot reach the Minikube IP because of the Docker/network driver, **do not claim physical integration is working**. Use the dashboard test buttons to demonstrate the deployed Minikube backend, then explain that the hardware path uses the same `voting/vote` MQTT topic and needs network reachability from the ESP32 to the broker NodePort.

## Useful commands
```powershell
kubectl get pods
kubectl get svc
kubectl logs deployment/voting-app --tail=100
kubectl logs deployment/mosquitto --tail=100
kubectl rollout restart deployment/voting-app
minikube stop
```

import json, os, threading, time
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse
import paho.mqtt.client as mqtt

HOST = "0.0.0.0"
PORT = int(os.getenv("PORT", "8080"))
MQTT_HOST = os.getenv("MQTT_HOST", "mosquitto")
MQTT_PORT = int(os.getenv("MQTT_PORT", "1883"))
VOTE_TOPIC = os.getenv("VOTE_TOPIC", "voting/vote")
TALLY_TOPIC = os.getenv("TALLY_TOPIC", "voting/tally")
STATIC = Path(__file__).parent / "static"
lock = threading.Lock()
state = {"cat": 0, "dog": 0, "events": [], "mqtt_connected": False}

def snapshot():
    with lock:
        cat, dog = state["cat"], state["dog"]
        return {"cat": cat, "dog": dog, "total": cat+dog,
                "events": list(state["events"][:20]),
                "mqtt_connected": state["mqtt_connected"]}

def publish_tally(client):
    s = snapshot()
    payload = json.dumps({"cat": s["cat"], "dog": s["dog"], "total": s["total"]})
    client.publish(TALLY_TOPIC, payload, qos=1, retain=True)

def accept_vote(choice, source="unknown"):
    if choice not in ("cat", "dog"):
        return False
    with lock:
        state[choice] += 1
        state["events"].insert(0, {"choice": choice, "source": source, "time": time.strftime("%H:%M:%S")})
        del state["events"][20:]
    return True

def on_connect(client, userdata, flags, reason_code, properties=None):
    ok = reason_code == 0
    with lock:
        state["mqtt_connected"] = ok
    if ok:
        client.subscribe(VOTE_TOPIC, qos=1)
        publish_tally(client)
        
def on_disconnect(client, userdata, disconnect_flags, reason_code, properties=None):
    with lock: state["mqtt_connected"] = False

def on_message(client, userdata, msg):
    try:
        data = json.loads(msg.payload.decode("utf-8"))
        choice = str(data.get("choice", "")).lower()
        source = str(data.get("device_id", "mqtt-device"))[:60]
        if accept_vote(choice, source): publish_tally(client)
    except Exception as e:
        print("Bad MQTT payload:", e, flush=True)

mqttc = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id="voting-service")
mqttc.on_connect = on_connect
mqttc.on_disconnect = on_disconnect
mqttc.on_message = on_message

def mqtt_worker():
    while True:
        try:
            mqttc.connect(MQTT_HOST, MQTT_PORT, 30)
            mqttc.loop_forever()
        except Exception as e:
            with lock: state["mqtt_connected"] = False
            print("MQTT reconnecting:", e, flush=True)
            time.sleep(3)

class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs): super().__init__(*args, directory=str(STATIC), **kwargs)
    def send_json(self, obj, status=200):
        body = json.dumps(obj).encode()
        self.send_response(status); self.send_header("Content-Type", "application/json")
        self.send_header("Cache-Control", "no-store"); self.send_header("Content-Length", str(len(body)))
        self.end_headers(); self.wfile.write(body)
    def do_GET(self):
        p = urlparse(self.path).path
        if p == "/api/tally": return self.send_json(snapshot())
        if p == "/health": return self.send_json({"ok": True, "mqtt_connected": snapshot()["mqtt_connected"]})
        if p == "/": self.path = "/index.html"
        return super().do_GET()
    def do_POST(self):
        p = urlparse(self.path).path
        n = int(self.headers.get("Content-Length", "0") or 0)
        try: data = json.loads(self.rfile.read(n) or b"{}")
        except: return self.send_json({"error":"invalid json"}, 400)
        if p == "/api/vote":
            choice = str(data.get("choice", "")).lower()
            if not accept_vote(choice, "dashboard"):
                return self.send_json({"error":"choice must be cat or dog"}, 400)
            publish_tally(mqttc); return self.send_json(snapshot())
        if p == "/api/reset":
            with lock:
                state["cat"] = state["dog"] = 0; state["events"].clear()
            publish_tally(mqttc); return self.send_json(snapshot())
        return self.send_json({"error":"not found"}, 404)

if __name__ == "__main__":
    threading.Thread(target=mqtt_worker, daemon=True).start()
    print(f"Voting service on :{PORT}; MQTT={MQTT_HOST}:{MQTT_PORT}", flush=True)
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()

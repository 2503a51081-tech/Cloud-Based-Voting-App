@echo off
setlocal
cd /d %~dp0
echo [1/6] Starting Minikube...
minikube start --driver=docker || goto :fail
echo [2/6] Building voting app image inside Minikube...
minikube image build -t voting-app:1.0 ./backend || goto :fail
echo [3/6] Deploying MQTT broker...
kubectl apply -f k8s/mosquitto-config.yaml || goto :fail
kubectl apply -f k8s/mosquitto.yaml || goto :fail
echo [4/6] Deploying voting service...
kubectl apply -f k8s/voting-app.yaml || goto :fail
echo [5/6] Waiting for pods...
kubectl rollout status deployment/mosquitto --timeout=120s || goto :fail
kubectl rollout status deployment/voting-app --timeout=120s || goto :fail
kubectl get pods,svc
echo [6/6] Opening dashboard...
minikube service voting-app
exit /b 0
:fail
echo.
echo DEPLOYMENT STOPPED. Read the error above and README.md.
pause
exit /b 1

#include <WiFi.h>
#include <PubSubClient.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

// EDIT THESE 3 VALUES BEFORE UPLOADING
const char* WIFI_SSID = "Oppo A5 Pro 5G";
const char* WIFI_PASSWORD = "1234567890";
const char* MQTT_HOST = "10.51.187.11";
const int MQTT_PORT = 1883;


const int CAT_BUTTON = 18;
const int DOG_BUTTON = 19;
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);
WiFiClient wifiClient; PubSubClient mqtt(wifiClient);
unsigned long lastCat=0,lastDog=0; const unsigned long DEBOUNCE=250;
int catCount=0,dogCount=0;

void drawTally(){
  display.clearDisplay(); display.setTextColor(SSD1306_WHITE);
  display.setTextSize(1); display.setCursor(0,0); display.println("VOTING APP - LIVE");
  display.setTextSize(2); display.setCursor(0,20); display.print("CAT:"); display.println(catCount);
  display.setCursor(0,42); display.print("DOG:"); display.println(dogCount); display.display();
}
void callback(char* topic, byte* payload, unsigned int length){
  String s; for(unsigned int i=0;i<length;i++) s+=(char)payload[i];
  int ci=s.indexOf("\"cat\":"); int di=s.indexOf("\"dog\":");
  if(ci>=0) catCount=s.substring(ci+6).toInt(); if(di>=0) dogCount=s.substring(di+6).toInt(); drawTally();
}
void connectMqtt(){
  while(!mqtt.connected()){
    String id="esp32-voter-"+String((uint32_t)ESP.getEfuseMac(),HEX);
    if(mqtt.connect(id.c_str())) mqtt.subscribe("voting/tally"); else delay(1500);
  }
}
void publishVote(const char* choice){
  String p=String("{\"choice\":\"")+choice+"\",\"device_id\":\"esp32-01\"}";
  mqtt.publish("voting/vote",p.c_str());
}
void setup(){
  Serial.begin(115200); pinMode(CAT_BUTTON,INPUT_PULLUP); pinMode(DOG_BUTTON,INPUT_PULLUP);
  Wire.begin(); display.begin(SSD1306_SWITCHCAPVCC,0x3C); drawTally();
  WiFi.begin(WIFI_SSID,WIFI_PASSWORD); while(WiFi.status()!=WL_CONNECTED){delay(500);Serial.print(".");}
  mqtt.setServer(MQTT_HOST,MQTT_PORT); mqtt.setCallback(callback); connectMqtt();
}
void loop(){
  if(!mqtt.connected()) connectMqtt(); mqtt.loop(); unsigned long now=millis();
  if(digitalRead(CAT_BUTTON)==LOW && now-lastCat>DEBOUNCE){lastCat=now;publishVote("cat");}
  if(digitalRead(DOG_BUTTON)==LOW && now-lastDog>DEBOUNCE){lastDog=now;publishVote("dog");}
}
